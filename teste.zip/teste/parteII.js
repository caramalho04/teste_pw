{
  "atores": [
    {
      "id": 1,
      "nome": "Leonardo DiCaprio",
      "data_nascimento": "1974-11-11",
      "filmes": [
        {
          "id": 101,
          "titulo": "Inception",
          "ano": 2010,
          "papel": "Dom Cobb"
        },
        {
          "id": 102,
          "titulo": "The Revenant",
          "ano": 2015,
          "papel": "Hugh Glass"
        }
      ]
    },
    {
      "id": 2,
      "nome": "Angelina Jolie",
      "data_nascimento": "1975-5-4",
      "filmes": [
        {
          "id": 103,
          "titulo": "First They Killed My Father",
          "ano": 2017,
          "papel": "Diretora"
        },
        {
          "id": 104,
          "titulo": "Africa",
          "ano": 2016,
          "papel": "Diretora"
        }
      ]
    }
  ]
}
